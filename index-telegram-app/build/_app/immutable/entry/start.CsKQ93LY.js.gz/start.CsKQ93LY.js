import{l as s,a}from"../chunks/Dmm1jFPB.js";export{s as load_css,a as start};
